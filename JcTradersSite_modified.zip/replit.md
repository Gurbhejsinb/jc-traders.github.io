# JC Traders - Crypto Trading Platform

## Overview

JC Traders is a full-stack cryptocurrency trading platform that enables users to trade digital assets including USDT, BNB, TRX, BTC, and ETH. The application provides wallet integration, real-time order processing, portfolio management, and transaction tracking capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management and caching
- Tailwind CSS with shadcn/ui component library for styling
- Ethers.js for Web3 wallet integration

**Design Decisions:**
- **Component-based UI:** Leverages shadcn/ui (Radix UI primitives) for accessible, customizable components
- **State Management:** React Query handles server state with automatic caching and refetching; React Context manages wallet connection state
- **Routing:** Wouter provides minimal routing overhead compared to React Router
- **Styling:** Utility-first approach with Tailwind CSS and CSS variables for theming support

**Directory Structure:**
- `/client/src/pages/` - Main application views (home, trade, portfolio, dashboard)
- `/client/src/components/` - Reusable UI components and business logic components
- `/client/src/components/ui/` - Shadcn/ui primitive components
- `/client/src/hooks/` - Custom React hooks for wallet, toast notifications, and mobile detection
- `/client/src/lib/` - Utility functions and Web3 provider implementations

### Backend Architecture

**Technology Stack:**
- Node.js with Express.js for the REST API server
- TypeScript throughout for type safety
- Drizzle ORM for database interactions with PostgreSQL
- In-memory storage fallback for development

**Design Decisions:**
- **REST API Pattern:** Simple RESTful endpoints for crypto assets, users, orders, and transactions
- **Database Abstraction:** Storage interface (`IStorage`) allows swapping between in-memory and PostgreSQL implementations
- **Middleware Architecture:** Express middleware for JSON parsing, request logging, and raw body capture
- **Development Mode:** Vite integration in development for hot module replacement

**API Structure:**
- `GET /api/crypto-assets` - Fetch available cryptocurrencies
- `POST /api/users/wallet` - Get or create user by wallet address
- `GET /api/orders/:userId` - Retrieve user orders
- `POST /api/orders` - Create new trading order
- `GET /api/transactions/:userId` - Fetch user transaction history
- `POST /api/transactions` - Record new transaction
- `GET /api/portfolio/:userId` - Get user portfolio holdings

### Data Storage

**Database Schema (PostgreSQL via Drizzle ORM):**

1. **users** - User accounts linked to wallet addresses
   - Stores wallet address, provider type (MetaMask, WalletConnect, etc.)
   - UUID primary key with unique wallet address constraint

2. **crypto_assets** - Supported cryptocurrencies
   - Symbol, name, network, contract address, decimals
   - Includes metadata like logo URL and active status

3. **orders** - Trading orders
   - Links users to asset swaps (from/to assets)
   - Tracks amounts, exchange rates, status (pending/processing/completed/failed)
   - Records transaction hashes and network fees

4. **transactions** - Individual blockchain transactions
   - Associated with orders and users
   - Type classification (buy, sell, swap, deposit, withdraw)
   - Block number and transaction hash tracking

5. **portfolio** - User asset holdings
   - Current balance per asset per user
   - Updated as transactions complete

**Design Rationale:**
- Decimal precision (36, 18) for accurate cryptocurrency amount representation
- Status fields enable order lifecycle tracking
- Separation of orders and transactions supports complex multi-step trades
- PostgreSQL chosen for ACID compliance and relationship management

### Authentication & Authorization

**Wallet-Based Authentication:**
- No traditional username/password system
- Users authenticate via Web3 wallet signatures
- Supported providers: MetaMask, WalletConnect, TrustWallet, TronLink
- Wallet address serves as unique user identifier

**Session Management:**
- Wallet connection state persisted in localStorage
- User data cached in React Query for efficient access
- Server-side validation of wallet addresses on API calls

**Design Rationale:**
- Web3-native authentication aligns with crypto trading use case
- Eliminates password management complexity
- Enables direct blockchain interaction from user wallets

## External Dependencies

### Third-Party Services

**Blockchain Networks:**
- Ethereum mainnet and BNB Smart Chain (BSC) for ERC-20/BEP-20 tokens
- TRON network for TRC-20 tokens
- Requires connection to network RPC endpoints (configured via wallet providers)

**Wallet Providers:**
- MetaMask browser extension API
- WalletConnect protocol for mobile wallet connections
- TronLink for TRON network interactions
- Each provider requires specific integration code in `/client/src/lib/web3.ts`

**Database:**
- PostgreSQL database (Neon serverless recommended based on `@neondatabase/serverless` dependency)
- Connection string via `DATABASE_URL` environment variable
- Drizzle ORM manages schema migrations in `/migrations` directory

### Development Tools

**Replit Integration:**
- `@replit/vite-plugin-cartographer` - Development mode route mapping
- `@replit/vite-plugin-dev-banner` - Development environment banner
- `@replit/vite-plugin-runtime-error-modal` - Enhanced error overlay

**Build & Development:**
- Vite for frontend bundling and dev server
- esbuild for backend bundling
- tsx for TypeScript execution in development
- PostCSS with Tailwind for CSS processing

### Key Libraries

**Frontend:**
- `@tanstack/react-query` - Data fetching and caching
- `ethers` - Ethereum JavaScript library for wallet interaction
- `wouter` - Lightweight routing
- `date-fns` - Date manipulation
- `react-hook-form` with `@hookform/resolvers` - Form state management
- `zod` - Schema validation

**Backend:**
- `drizzle-orm` - Type-safe SQL query builder
- `drizzle-zod` - Zod schema generation from Drizzle schemas
- `connect-pg-simple` - PostgreSQL session store

**Shared:**
- `/shared/schema.ts` - Shared TypeScript types and Zod schemas between frontend and backend

### Environment Configuration

Required environment variables:
- `DATABASE_URL` - PostgreSQL connection string
- `NODE_ENV` - Application environment (development/production)