import { ethers } from "ethers";

export interface WalletProvider {
  name: string;
  connect: () => Promise<string>;
  getBalance: (address: string) => Promise<string>;
  sendTransaction: (to: string, amount: string) => Promise<string>;
}

export class MetaMaskProvider implements WalletProvider {
  name = "MetaMask";

  async connect(): Promise<string> {
    if (typeof window.ethereum !== "undefined") {
      try {
        const accounts = await window.ethereum.request({
          method: "eth_requestAccounts",
        });
        return accounts[0];
      } catch (error) {
        throw new Error("User rejected the request");
      }
    } else {
      throw new Error("MetaMask is not installed");
    }
  }

  async getBalance(address: string): Promise<string> {
    if (typeof window.ethereum !== "undefined") {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const balance = await provider.getBalance(address);
      return ethers.formatEther(balance);
    }
    throw new Error("MetaMask is not available");
  }

  async sendTransaction(to: string, amount: string): Promise<string> {
    if (typeof window.ethereum !== "undefined") {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      
      const tx = await signer.sendTransaction({
        to,
        value: ethers.parseEther(amount),
      });
      
      return tx.hash;
    }
    throw new Error("MetaMask is not available");
  }
}

export class WalletConnectProvider implements WalletProvider {
  name = "WalletConnect";

  async connect(): Promise<string> {
    // TODO: Implement WalletConnect integration
    throw new Error("WalletConnect integration not implemented");
  }

  async getBalance(address: string): Promise<string> {
    throw new Error("WalletConnect integration not implemented");
  }

  async sendTransaction(to: string, amount: string): Promise<string> {
    throw new Error("WalletConnect integration not implemented");
  }
}

export class TrustWalletProvider implements WalletProvider {
  name = "Trust Wallet";

  async connect(): Promise<string> {
    // Trust Wallet uses the same ethereum provider as MetaMask
    if (typeof window.ethereum !== "undefined") {
      try {
        const accounts = await window.ethereum.request({
          method: "eth_requestAccounts",
        });
        return accounts[0];
      } catch (error) {
        throw new Error("User rejected the request");
      }
    } else {
      throw new Error("Trust Wallet is not installed");
    }
  }

  async getBalance(address: string): Promise<string> {
    if (typeof window.ethereum !== "undefined") {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const balance = await provider.getBalance(address);
      return ethers.formatEther(balance);
    }
    throw new Error("Trust Wallet is not available");
  }

  async sendTransaction(to: string, amount: string): Promise<string> {
    if (typeof window.ethereum !== "undefined") {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      
      const tx = await signer.sendTransaction({
        to,
        value: ethers.parseEther(amount),
      });
      
      return tx.hash;
    }
    throw new Error("Trust Wallet is not available");
  }
}

export class TronLinkProvider implements WalletProvider {
  name = "TronLink";

  async connect(): Promise<string> {
    if (typeof window.tronWeb !== "undefined") {
      try {
        const address = window.tronWeb.defaultAddress?.base58;
        if (address) {
          return address;
        } else {
          throw new Error("Please unlock TronLink wallet");
        }
      } catch (error) {
        throw new Error("Failed to connect to TronLink");
      }
    } else {
      throw new Error("TronLink is not installed");
    }
  }

  async getBalance(address: string): Promise<string> {
    if (typeof window.tronWeb !== "undefined") {
      try {
        const balance = await window.tronWeb.trx.getBalance(address);
        return (balance / 1000000).toString(); // Convert from sun to TRX
      } catch (error) {
        throw new Error("Failed to get TRX balance");
      }
    }
    throw new Error("TronLink is not available");
  }

  async sendTransaction(to: string, amount: string): Promise<string> {
    if (typeof window.tronWeb !== "undefined") {
      try {
        const tx = await window.tronWeb.trx.sendTransaction(
          to,
          parseFloat(amount) * 1000000 // Convert TRX to sun
        );
        return tx.txid;
      } catch (error) {
        throw new Error("Transaction failed");
      }
    }
    throw new Error("TronLink is not available");
  }
}

// Extend Window interface for wallet providers
declare global {
  interface Window {
    ethereum?: any;
    tronWeb?: any;
  }
}

export const walletProviders = {
  MetaMask: new MetaMaskProvider(),
  WalletConnect: new WalletConnectProvider(),
  TrustWallet: new TrustWalletProvider(),
  TronLink: new TronLinkProvider(),
};
