import Navigation from "@/components/navigation";
import OrderProcess from "@/components/order-process";
import CryptoCards from "@/components/crypto-cards";
import Footer from "@/components/footer";
import type { CryptoAsset } from "@shared/schema";

export default function Trade() {
  const handleSelectCrypto = (asset: CryptoAsset) => {
    // Scroll to order process or pre-fill the form
    document.getElementById("trade")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      <main>
        <section className="pt-16 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">
              Start Trading <span className="gradient-text">Crypto</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Select your preferred cryptocurrency and start trading instantly
            </p>
          </div>
        </section>
        <CryptoCards onSelectCrypto={handleSelectCrypto} />
        <OrderProcess />
      </main>
      <Footer />
    </div>
  );
}
