import Navigation from "@/components/navigation";
import TransactionDashboard from "@/components/transaction-dashboard";
import Footer from "@/components/footer";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      <main className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-8">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            Trading <span className="gradient-text">Dashboard</span>
          </h1>
          <p className="text-xl text-muted-foreground">
            Monitor your trades, transactions, and portfolio performance
          </p>
        </div>
        <TransactionDashboard />
      </main>
      <Footer />
    </div>
  );
}
