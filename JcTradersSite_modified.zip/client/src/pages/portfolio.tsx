import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown } from "lucide-react";
import { useWallet } from "@/hooks/use-wallet";
import type { Portfolio, CryptoAsset } from "@shared/schema";

// Mock data for demonstration
const mockPortfolioData = [
  {
    symbol: "USDT",
    balance: "2450.00",
    value: "2450.00",
    change24h: "+0.12%",
    network: "BEP20",
    isPositive: true,
  },
  {
    symbol: "BNB",
    balance: "8.42",
    value: "2631.25",
    change24h: "+2.45%",
    network: "BSC",
    isPositive: true,
  },
  {
    symbol: "TRX",
    balance: "15250",
    value: "1296.25",
    change24h: "-1.23%",
    network: "TRON",
    isPositive: false,
  },
  {
    symbol: "BTC",
    balance: "0.0245",
    value: "1059.62",
    change24h: "+3.45%",
    network: "BTC",
    isPositive: true,
  },
];

export default function Portfolio() {
  const { user, isConnected } = useWallet();

  const { data: cryptoAssets } = useQuery<CryptoAsset[]>({
    queryKey: ["/api/crypto-assets"],
  });

  if (!isConnected) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Navigation />
        <main className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-8">
              Your <span className="gradient-text">Portfolio</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Connect your wallet to view your portfolio
            </p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const totalValue = mockPortfolioData.reduce((sum, item) => sum + parseFloat(item.value), 0);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      <main className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">
              Your <span className="gradient-text">Portfolio</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Track and manage your cryptocurrency investments
            </p>
          </div>

          {/* Total Portfolio Value */}
          <Card className="mb-8 crypto-card border-border">
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-sm text-muted-foreground mb-2">Total Portfolio Value</div>
                <div className="font-mono text-5xl font-bold gradient-text mb-4" data-testid="portfolio-total-value">
                  ${totalValue.toLocaleString()}
                </div>
                <div className="flex items-center justify-center">
                  <span className="text-success flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    +12.5% (24h)
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Portfolio Assets */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockPortfolioData.map((asset, index) => (
              <Card key={index} className="crypto-card border-border card-hover" data-testid={`portfolio-asset-${asset.symbol}`}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{asset.symbol}</CardTitle>
                    <Badge variant="outline">{asset.network}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <div className="text-sm text-muted-foreground">Balance</div>
                      <div className="font-mono text-xl font-semibold" data-testid={`balance-${asset.symbol}`}>
                        {asset.balance}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Value</div>
                      <div className="font-mono text-lg" data-testid={`value-${asset.symbol}`}>
                        ${asset.value}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">24h Change</span>
                      <span className={`flex items-center text-sm ${
                        asset.isPositive ? "text-success" : "text-destructive"
                      }`}>
                        {asset.isPositive ? (
                          <TrendingUp className="w-4 h-4 mr-1" />
                        ) : (
                          <TrendingDown className="w-4 h-4 mr-1" />
                        )}
                        {asset.change24h}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
