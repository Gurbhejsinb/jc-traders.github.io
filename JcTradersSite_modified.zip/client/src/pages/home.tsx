import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { CheckCircle } from "lucide-react";
import ProductGallery from "@/components/product-gallery";
import PaymentModal from "@/components/payment-modal";
import TransactionHashModal from "@/components/transaction-hash-modal";
import CustomerInfoModal from "@/components/customer-info-modal";
import type { Product } from "@shared/schema";

export default function Home() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedSize, setSelectedSize] = useState<string>("M");
  const [paymentMethod, setPaymentMethod] = useState<string>("");
  const [transactionHash, setTransactionHash] = useState<string>("");
  
  const [showSizeModal, setShowSizeModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const handleBuyClick = (product: Product) => {
    setSelectedProduct(product);
    setShowSizeModal(true);
  };

  const handleSizeSelect = () => {
    setShowSizeModal(false);
    setShowPaymentModal(true);
  };

  const handlePaymentComplete = (method: string) => {
    setPaymentMethod(method);
    setShowPaymentModal(false);
    setShowTransactionModal(true);
  };

  const handleTransactionSubmit = (txHash: string) => {
    setTransactionHash(txHash);
    setShowTransactionModal(false);
    setShowCustomerModal(true);
  };

  const handleOrderSuccess = () => {
    setShowCustomerModal(false);
    setShowSuccessModal(true);
    // Reset state
    setTimeout(() => {
      setSelectedProduct(null);
      setSelectedSize("M");
      setPaymentMethod("");
      setTransactionHash("");
    }, 500);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary rounded-full blur-3xl"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-32">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <span className="text-2xl font-bold">JC</span>
              </div>
              <h1 className="text-5xl sm:text-6xl font-bold">JC Traders</h1>
            </div>
            <p className="text-2xl sm:text-3xl font-bold mb-6">
              Premium <span className="gradient-text">T-Shirt Collections</span>
            </p>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Exclusive designs with crypto payment. Get your unique JC Traders merchandise today!
            </p>
            <div className="flex flex-wrap gap-4 justify-center text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-success" />
                <span>Premium Quality</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-success" />
                <span>Crypto Payment</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-success" />
                <span>Fast Shipping</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Products */}
      <ProductGallery onBuyClick={handleBuyClick} />

      {/* Features */}
      <section className="py-16 border-t border-border bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Why Choose Us</h2>
            <p className="text-muted-foreground">Premium quality with secure crypto payments</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Premium Quality</h3>
              <p className="text-sm text-muted-foreground">100% cotton, comfortable and durable</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Crypto Payments</h3>
              <p className="text-sm text-muted-foreground">Pay with USDT, TRON, or BNB</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Fast Delivery</h3>
              <p className="text-sm text-muted-foreground">Worldwide shipping available</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-muted-foreground">
          <p>© 2024 JC Traders. All rights reserved.</p>
        </div>
      </footer>

      {/* Size Selection Modal */}
      <Dialog open={showSizeModal} onOpenChange={setShowSizeModal}>
        <DialogContent data-testid="size-modal">
          <div className="space-y-4">
            <h3 className="text-xl font-bold">Select Size</h3>
            {selectedProduct && (
              <div className="p-4 bg-muted/50 rounded-lg">
                <div className="font-semibold">{selectedProduct.name}</div>
                <div className="text-lg font-bold gradient-text">${selectedProduct.price}</div>
              </div>
            )}
            <div className="grid grid-cols-5 gap-2">
              {selectedProduct?.sizes?.map((size) => (
                <Button
                  key={size}
                  variant={selectedSize === size ? "default" : "outline"}
                  onClick={() => setSelectedSize(size)}
                  data-testid={`button-size-${size}`}
                >
                  {size}
                </Button>
              ))}
            </div>
            <Button
              onClick={handleSizeSelect}
              className="w-full glow-effect"
              data-testid="button-continue-size"
            >
              Continue
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        product={selectedProduct}
        selectedSize={selectedSize}
        onPaymentComplete={handlePaymentComplete}
      />

      {/* Transaction Hash Modal */}
      <TransactionHashModal
        isOpen={showTransactionModal}
        onClose={() => setShowTransactionModal(false)}
        product={selectedProduct}
        selectedSize={selectedSize}
        paymentMethod={paymentMethod}
        onSubmit={handleTransactionSubmit}
      />

      {/* Customer Info Modal */}
      <CustomerInfoModal
        isOpen={showCustomerModal}
        onClose={() => setShowCustomerModal(false)}
        product={selectedProduct}
        selectedSize={selectedSize}
        paymentMethod={paymentMethod}
        transactionHash={transactionHash}
        onSuccess={handleOrderSuccess}
      />

      {/* Success Modal */}
      <Dialog open={showSuccessModal} onOpenChange={setShowSuccessModal}>
        <DialogContent data-testid="success-modal">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-success/20 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8 text-success" />
            </div>
            <h3 className="text-2xl font-bold">Order Placed Successfully!</h3>
            <p className="text-muted-foreground">
              Thank you for your purchase. Order details have been sent to your email and our team.
            </p>
            <Button
              onClick={() => setShowSuccessModal(false)}
              className="w-full"
              data-testid="button-close-success"
            >
              Continue Shopping
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
