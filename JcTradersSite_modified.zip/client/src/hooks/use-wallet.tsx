import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { walletProviders, type WalletProvider } from "@/lib/web3";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";

interface WalletContextType {
  isConnected: boolean;
  walletAddress: string | null;
  walletProvider: string | null;
  user: User | null;
  connect: (providerName: keyof typeof walletProviders) => Promise<void>;
  disconnect: () => void;
  getBalance: () => Promise<string | null>;
}

const WalletContext = createContext<WalletContextType | null>(null);

export function useWallet() {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error("useWallet must be used within a WalletProvider");
  }
  return context;
}

interface WalletProviderProps {
  children: ReactNode;
}

export function WalletProvider({ children }: WalletProviderProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [walletProvider, setWalletProvider] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [currentProvider, setCurrentProvider] = useState<WalletProvider | null>(null);
  const { toast } = useToast();

  // Check for existing connection on mount
  useEffect(() => {
    const savedAddress = localStorage.getItem("walletAddress");
    const savedProvider = localStorage.getItem("walletProvider");
    const savedUser = localStorage.getItem("user");

    if (savedAddress && savedProvider && savedUser) {
      setWalletAddress(savedAddress);
      setWalletProvider(savedProvider);
      setUser(JSON.parse(savedUser));
      setIsConnected(true);
      setCurrentProvider(walletProviders[savedProvider as keyof typeof walletProviders]);
    }
  }, []);

  const connect = async (providerName: keyof typeof walletProviders) => {
    try {
      const provider = walletProviders[providerName];
      setCurrentProvider(provider);

      const address = await provider.connect();
      setWalletAddress(address);
      setWalletProvider(providerName);
      setIsConnected(true);

      // Create or get user from backend
      const response = await apiRequest("POST", "/api/users/wallet", {
        walletAddress: address,
        walletProvider: providerName,
      });

      const userData = await response.json();
      setUser(userData);

      // Save to localStorage
      localStorage.setItem("walletAddress", address);
      localStorage.setItem("walletProvider", providerName);
      localStorage.setItem("user", JSON.stringify(userData));

      toast({
        title: "Wallet Connected",
        description: `Successfully connected to ${providerName}`,
      });
    } catch (error) {
      console.error("Failed to connect wallet:", error);
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Failed to connect wallet",
        variant: "destructive",
      });
    }
  };

  const disconnect = () => {
    setIsConnected(false);
    setWalletAddress(null);
    setWalletProvider(null);
    setUser(null);
    setCurrentProvider(null);

    // Clear localStorage
    localStorage.removeItem("walletAddress");
    localStorage.removeItem("walletProvider");
    localStorage.removeItem("user");

    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
    });
  };

  const getBalance = async (): Promise<string | null> => {
    if (!currentProvider || !walletAddress) {
      return null;
    }

    try {
      const balance = await currentProvider.getBalance(walletAddress);
      return balance;
    } catch (error) {
      console.error("Failed to get balance:", error);
      return null;
    }
  };

  return (
    <WalletContext.Provider
      value={{
        isConnected,
        walletAddress,
        walletProvider,
        user,
        connect,
        disconnect,
        getBalance,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}
