import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { Product } from "@shared/schema";

interface TransactionHashModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
  selectedSize: string;
  paymentMethod: string;
  onSubmit: (transactionHash: string) => void;
}

export default function TransactionHashModal({ isOpen, onClose, product, selectedSize, paymentMethod, onSubmit }: TransactionHashModalProps) {
  const [transactionHash, setTransactionHash] = useState("");
  const [error, setError] = useState("");

  if (!product) return null;

  const handleSubmit = () => {
    if (!transactionHash.trim()) {
      setError("Please enter your transaction hash");
      return;
    }
    
    if (transactionHash.length < 10) {
      setError("Transaction hash seems too short. Please verify.");
      return;
    }

    onSubmit(transactionHash);
    setTransactionHash("");
    setError("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md" data-testid="transaction-hash-modal">
        <DialogHeader>
          <DialogTitle>Enter Transaction Hash</DialogTitle>
          <DialogDescription>
            Please paste your transaction hash from your crypto wallet
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="text-sm text-muted-foreground">Order Details</div>
            <div className="font-semibold">{product.name}</div>
            <div className="text-sm">Size: {selectedSize}</div>
            <div className="text-sm">Payment: {paymentMethod}</div>
            <div className="text-lg font-bold gradient-text mt-2">${product.price}</div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="txhash">Transaction Hash *</Label>
            <Input
              id="txhash"
              type="text"
              value={transactionHash}
              onChange={(e) => {
                setTransactionHash(e.target.value);
                setError("");
              }}
              placeholder="0x1234567890abcdef..."
              className={error ? "border-destructive" : ""}
              data-testid="input-transaction-hash"
            />
            {error && (
              <p className="text-sm text-destructive">{error}</p>
            )}
            <p className="text-xs text-muted-foreground">
              Copy the transaction hash from your wallet after completing the payment
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
              data-testid="button-cancel-hash"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              className="flex-1 glow-effect"
              data-testid="button-submit-hash"
            >
              Submit
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
