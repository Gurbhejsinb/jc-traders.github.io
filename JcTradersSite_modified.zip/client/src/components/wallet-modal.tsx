import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info, ArrowRight } from "lucide-react";
import { useWallet } from "@/hooks/use-wallet";
import { walletProviders } from "@/lib/web3";

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const walletOptions = [
  {
    name: "MetaMask",
    description: "Popular",
    icon: "https://upload.wikimedia.org/wikipedia/commons/3/36/MetaMask_Fox.svg",
    supported: ["USDT", "BNB", "ETH"],
  },
  {
    name: "WalletConnect",
    description: "Mobile & Desktop",
    icon: "https://walletconnect.com/walletconnect-logo.svg",
    supported: ["Multi-chain"],
  },
  {
    name: "TrustWallet",
    description: "BEP20 & BNB",
    icon: "https://trustwallet.com/assets/images/media/assets/trust_platform.svg",
    supported: ["USDT", "BNB"],
  },
  {
    name: "TronLink",
    description: "TRON Network",
    icon: "https://www.tronlink.org/static/media/logo.7de88c4f.png",
    supported: ["TRX", "USDT-TRC20"],
  },
];

export default function WalletModal({ isOpen, onClose }: WalletModalProps) {
  const { connect } = useWallet();

  const handleConnect = async (providerName: string) => {
    try {
      await connect(providerName as keyof typeof walletProviders);
      onClose();
    } catch (error) {
      console.error("Failed to connect:", error);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md" data-testid="wallet-modal">
        <DialogHeader>
          <DialogTitle data-testid="modal-title">Connect Wallet</DialogTitle>
        </DialogHeader>
        
        <p className="text-muted-foreground mb-6">
          Choose your preferred wallet provider to connect
        </p>
        
        <div className="space-y-3">
          {walletOptions.map((wallet) => (
            <Button
              key={wallet.name}
              variant="outline"
              onClick={() => handleConnect(wallet.name)}
              className="w-full justify-between p-4 h-auto wallet-option"
              data-testid={`button-connect-${wallet.name.toLowerCase()}`}
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                  <span className="text-xs font-bold">
                    {wallet.name.substring(0, 2)}
                  </span>
                </div>
                <div className="text-left">
                  <div className="font-semibold">{wallet.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {wallet.description}
                  </div>
                </div>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </Button>
          ))}
        </div>
        
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription className="text-xs">
            We do not own your private keys and cannot access funds without your confirmation.
          </AlertDescription>
        </Alert>
      </DialogContent>
    </Dialog>
  );
}
