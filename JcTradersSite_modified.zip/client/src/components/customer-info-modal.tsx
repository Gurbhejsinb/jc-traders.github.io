import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Product, InsertOrder } from "@shared/schema";

interface CustomerInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
  selectedSize: string;
  paymentMethod: string;
  transactionHash: string;
  onSuccess: () => void;
}

export default function CustomerInfoModal({ 
  isOpen, 
  onClose, 
  product, 
  selectedSize, 
  paymentMethod, 
  transactionHash,
  onSuccess 
}: CustomerInfoModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    mobile: "",
    address: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const createOrderMutation = useMutation({
    mutationFn: async (orderData: InsertOrder) => {
      const response = await apiRequest("POST", "/api/orders", orderData);
      return response.json();
    },
    onSuccess: async (order) => {
      // Send email with order details
      await apiRequest("POST", `/api/orders/${order.id}/send-email`, {});
      
      toast({
        title: "Order Placed Successfully!",
        description: "Your order details have been sent to your email.",
      });
      
      setFormData({ name: "", email: "", mobile: "", address: "" });
      onSuccess();
      onClose();
    },
    onError: () => {
      toast({
        title: "Order Failed",
        description: "Failed to place order. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (!product) return null;

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.email.trim()) newErrors.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = "Invalid email format";
    if (!formData.mobile.trim()) newErrors.mobile = "Mobile number is required";
    if (!formData.address.trim()) newErrors.address = "Address is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;

    const orderData: InsertOrder = {
      productId: product.id,
      productName: product.name,
      size: selectedSize,
      price: product.price,
      paymentMethod,
      transactionHash,
      customerName: formData.name,
      customerEmail: formData.email,
      customerMobile: formData.mobile,
      customerAddress: formData.address,
      status: "pending",
    };

    createOrderMutation.mutate(orderData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg" data-testid="customer-info-modal">
        <DialogHeader>
          <DialogTitle>Delivery Information</DialogTitle>
          <DialogDescription>
            Please provide your details for order delivery
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 bg-muted/50 rounded-lg text-sm">
            <div className="font-semibold">{product.name} - Size {selectedSize}</div>
            <div className="text-muted-foreground">Payment: {paymentMethod}</div>
            <div className="text-muted-foreground truncate">TX: {transactionHash.substring(0, 20)}...</div>
          </div>

          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="John Doe"
                className={errors.name ? "border-destructive" : ""}
                data-testid="input-customer-name"
              />
              {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
            </div>

            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="john@example.com"
                className={errors.email ? "border-destructive" : ""}
                data-testid="input-customer-email"
              />
              {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
            </div>

            <div>
              <Label htmlFor="mobile">Mobile Number *</Label>
              <Input
                id="mobile"
                type="tel"
                value={formData.mobile}
                onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                placeholder="+1 234 567 8900"
                className={errors.mobile ? "border-destructive" : ""}
                data-testid="input-customer-mobile"
              />
              {errors.mobile && <p className="text-sm text-destructive mt-1">{errors.mobile}</p>}
            </div>

            <div>
              <Label htmlFor="address">Delivery Address *</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="123 Main St, City, State, ZIP"
                rows={3}
                className={errors.address ? "border-destructive" : ""}
                data-testid="input-customer-address"
              />
              {errors.address && <p className="text-sm text-destructive mt-1">{errors.address}</p>}
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={createOrderMutation.isPending}
              data-testid="button-cancel-info"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              className="flex-1 glow-effect"
              disabled={createOrderMutation.isPending}
              data-testid="button-submit-order"
            >
              {createOrderMutation.isPending ? "Processing..." : "Place Order"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
