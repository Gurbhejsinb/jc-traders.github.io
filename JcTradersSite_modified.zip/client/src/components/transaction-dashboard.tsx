import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, CheckCircle, Clock, X } from "lucide-react";
import { useWallet } from "@/hooks/use-wallet";
import type { Order, Transaction, Portfolio, CryptoAsset } from "@shared/schema";

// Mock portfolio data
const mockPortfolioData = [
  { symbol: "USDT", balance: "2450.00", value: "2450.00", network: "BEP20" },
  { symbol: "BNB", balance: "8.42", value: "2631.25", network: "BSC" },
  { symbol: "TRX", balance: "15250", value: "1296.25", network: "TRON" },
];

export default function TransactionDashboard() {
  const { user } = useWallet();

  const { data: orders, isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders", user?.id],
    enabled: !!user?.id,
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions", user?.id],
    enabled: !!user?.id,
  });

  const { data: cryptoAssets } = useQuery<CryptoAsset[]>({
    queryKey: ["/api/crypto-assets"],
  });

  const getAssetSymbol = (assetId: string | null) => {
    if (!assetId || !cryptoAssets) return "N/A";
    const asset = cryptoAssets.find(a => a.id === assetId);
    return asset?.symbol || "N/A";
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-success" />;
      case "processing":
      case "pending":
        return <Clock className="w-4 h-4 text-primary pulse-animation" />;
      case "failed":
        return <X className="w-4 h-4 text-destructive" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-success/20 text-success";
      case "processing":
        return "bg-primary/20 text-primary";
      case "pending":
        return "bg-yellow-500/20 text-yellow-500";
      case "failed":
        return "bg-destructive/20 text-destructive";
      default:
        return "bg-muted/20 text-muted-foreground";
    }
  };

  const totalPortfolioValue = mockPortfolioData.reduce((sum, item) => sum + parseFloat(item.value), 0);

  if (!user) {
    return (
      <section id="dashboard" className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Transaction Dashboard</h2>
            <p className="text-muted-foreground mb-8">Connect your wallet to view your trading dashboard</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="dashboard" className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Transaction Dashboard</h2>
          <p className="text-muted-foreground">Track and manage all your transactions in one place</p>
        </div>
        
        <div className="crypto-card rounded-xl overflow-hidden">
          <Tabs defaultValue="orders" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-transparent border-b border-border rounded-none h-auto">
              <TabsTrigger 
                value="orders" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:bg-transparent rounded-none py-4"
                data-testid="tab-active-orders"
              >
                Active Orders
              </TabsTrigger>
              <TabsTrigger 
                value="history" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:bg-transparent rounded-none py-4"
                data-testid="tab-transaction-history"
              >
                Transaction History
              </TabsTrigger>
              <TabsTrigger 
                value="wallet" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:bg-transparent rounded-none py-4"
                data-testid="tab-wallet-balance"
              >
                Wallet Balance
              </TabsTrigger>
            </TabsList>

            <TabsContent value="orders" className="p-6">
              <div className="space-y-4">
                {ordersLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="bg-muted/50 rounded-lg p-4 animate-pulse">
                        <div className="h-4 bg-muted rounded mb-2"></div>
                        <div className="h-4 bg-muted rounded w-3/4"></div>
                      </div>
                    ))}
                  </div>
                ) : orders && orders.length > 0 ? (
                  orders.map((order) => (
                    <div key={order.id} className="bg-muted/50 rounded-lg p-4 hover:bg-muted/70 transition-colors" data-testid={`order-${order.id}`}>
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                            <TrendingUp className="w-5 h-5 text-primary" />
                          </div>
                          <div>
                            <div className="font-semibold">
                              Buy {getAssetSymbol(order.toAssetId)} with {getAssetSymbol(order.fromAssetId)}
                            </div>
                            <div className="text-sm text-muted-foreground font-mono">
                              Order #{order.id.substring(0, 12)}...
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <div className="font-mono font-semibold">
                              {order.toAmount} {getAssetSymbol(order.toAssetId)}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              ≈ {order.fromAmount} {getAssetSymbol(order.fromAssetId)}
                            </div>
                          </div>
                          <Badge className={getStatusColor(order.status)}>
                            <div className="flex items-center gap-1">
                              {getStatusIcon(order.status)}
                              {order.status}
                            </div>
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12" data-testid="empty-orders">
                    <TrendingUp className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No active orders</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="history" className="p-6">
              <div className="space-y-6">
                {transactionsLoading ? (
                  <div className="space-y-6">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="relative pl-10 animate-pulse">
                        <div className="absolute left-0 top-0 w-8 h-8 bg-muted rounded-full"></div>
                        <div className="bg-muted/50 rounded-lg p-4">
                          <div className="h-4 bg-muted rounded mb-2"></div>
                          <div className="h-4 bg-muted rounded w-2/3"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : transactions && transactions.length > 0 ? (
                  <div className="relative transaction-timeline">
                    {transactions.map((transaction, index) => (
                      <div key={transaction.id} className="relative pl-10 mb-6" data-testid={`transaction-${transaction.id}`}>
                        <div className="absolute left-0 top-0">
                          <div className="w-8 h-8 bg-success rounded-full flex items-center justify-center border-4 border-background">
                            <CheckCircle className="w-4 h-4 text-success-foreground" />
                          </div>
                        </div>
                        <div className="bg-muted/50 rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <div className="font-semibold">{transaction.type} {getAssetSymbol(transaction.assetId)}</div>
                              <div className="text-sm text-muted-foreground capitalize">{transaction.status}</div>
                            </div>
                            <div className="text-right">
                              <div className="font-mono font-semibold text-success">
                                +{transaction.amount} {getAssetSymbol(transaction.assetId)}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {transaction.createdAt && new Date(transaction.createdAt).toLocaleString()}
                              </div>
                            </div>
                          </div>
                          {transaction.transactionHash && (
                            <div className="text-sm text-muted-foreground font-mono">
                              TxID: {transaction.transactionHash.substring(0, 10)}...
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12" data-testid="empty-transactions">
                    <CheckCircle className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No transaction history</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="wallet" className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {mockPortfolioData.map((wallet, index) => (
                  <div key={index} className="bg-muted/50 rounded-lg p-6" data-testid={`wallet-${wallet.symbol}`}>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-sm text-muted-foreground">{wallet.symbol} Balance</span>
                      <Badge variant="outline" className="text-xs">
                        {wallet.network}
                      </Badge>
                    </div>
                    <div className="font-mono text-2xl font-bold mb-1" data-testid={`balance-${wallet.symbol}`}>
                      {wallet.balance}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      ≈ ${wallet.value} USD
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Total Portfolio Value */}
              <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg p-6">
                <div className="text-sm text-muted-foreground mb-2">Total Portfolio Value</div>
                <div className="font-mono text-4xl font-bold gradient-text mb-2" data-testid="total-portfolio-value">
                  ${totalPortfolioValue.toLocaleString()}
                </div>
                <div className="flex items-center">
                  <span className="text-sm text-success flex items-center">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    +12.5% (24h)
                  </span>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  );
}
