import { Shield, Zap, BarChart3, Clock } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Secure Wallets",
    description: "Bank-grade security for your crypto assets with multi-signature protection",
    color: "primary",
  },
  {
    icon: Zap,
    title: "Instant Transactions",
    description: "Lightning-fast execution with real-time order processing",
    color: "secondary",
  },
  {
    icon: BarChart3,
    title: "Advanced Analytics",
    description: "Professional trading tools with real-time market data",
    color: "primary",
  },
  {
    icon: Clock,
    title: "24/7 Support",
    description: "Round-the-clock customer service for all your trading needs",
    color: "secondary",
  },
];

export default function FeaturesSection() {
  return (
    <section className="py-16 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Why Choose JC Traders</h2>
          <p className="text-muted-foreground">Professional trading platform with advanced features</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="crypto-card rounded-xl p-6 text-center card-hover" data-testid={`card-feature-${index}`}>
                <div className={`w-14 h-14 bg-${feature.color}/20 rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <Icon className={`w-7 h-7 text-${feature.color}`} />
                </div>
                <h3 className="text-lg font-semibold mb-2" data-testid={`text-feature-title-${index}`}>{feature.title}</h3>
                <p className="text-sm text-muted-foreground" data-testid={`text-feature-description-${index}`}>{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
