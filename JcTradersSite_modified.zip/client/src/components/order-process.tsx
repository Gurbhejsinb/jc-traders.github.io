import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useWallet } from "@/hooks/use-wallet";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { CryptoAsset, InsertOrder } from "@shared/schema";
import OrderConfirmationModal from "./order-confirmation-modal";

const steps = [
  { id: 1, title: "Select Asset" },
  { id: 2, title: "Enter Amount" },
  { id: 3, title: "Review Order" },
  { id: 4, title: "Confirm" },
];

export default function OrderProcess() {
  const [currentStep, setCurrentStep] = useState(1);
  const [fromAsset, setFromAsset] = useState<string>("");
  const [toAsset, setToAsset] = useState<string>("");
  const [fromAmount, setFromAmount] = useState<string>("");
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<any>(null);

  const { user, isConnected } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: cryptoAssets } = useQuery<CryptoAsset[]>({
    queryKey: ["/api/crypto-assets"],
  });

  const createOrderMutation = useMutation({
    mutationFn: async (orderData: InsertOrder) => {
      const response = await apiRequest("POST", "/api/orders", orderData);
      return response.json();
    },
    onSuccess: (order) => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      setCreatedOrder(order);
      setIsConfirmationOpen(true);
      setCurrentStep(1);
      setFromAsset("");
      setToAsset("");
      setFromAmount("");
    },
    onError: () => {
      toast({
        title: "Order Failed",
        description: "Failed to create order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const fromAssetData = cryptoAssets?.find(asset => asset.id === fromAsset);
  const toAssetData = cryptoAssets?.find(asset => asset.id === toAsset);

  const mockExchangeRate = 0.000024; // Mock rate: 1 USDT = 0.000024 BTC
  const calculatedToAmount = fromAmount ? (parseFloat(fromAmount) * mockExchangeRate).toFixed(8) : "0";
  const networkFee = "1.25"; // Mock network fee

  const handleNext = () => {
    if (!isConnected) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to continue",
        variant: "destructive",
      });
      return;
    }

    if (currentStep === 1 && (!fromAsset || !toAsset)) {
      toast({
        title: "Invalid Selection",
        description: "Please select both assets",
        variant: "destructive",
      });
      return;
    }

    if (currentStep === 2 && (!fromAmount || parseFloat(fromAmount) <= 0)) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleConfirmOrder = () => {
    if (!user) return;

    const orderData: InsertOrder = {
      userId: user.id,
      fromAssetId: fromAsset,
      toAssetId: toAsset,
      fromAmount,
      toAmount: calculatedToAmount,
      exchangeRate: mockExchangeRate.toString(),
      networkFee,
      status: "pending",
    };

    createOrderMutation.mutate(orderData);
  };

  return (
    <>
      <section id="trade" className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Streamlined Buy Order Process</h2>
            <p className="text-muted-foreground">Complete your purchase in 4 simple steps</p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            {/* Progress Bar */}
            <div className="flex items-center justify-between mb-12">
              {steps.map((step, index) => (
                <div key={step.id} className="flex-1">
                  <div className="flex items-center">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold ${
                      currentStep >= step.id 
                        ? currentStep === step.id 
                          ? "step-active text-white" 
                          : "step-completed text-white"
                        : "step-inactive text-muted-foreground"
                    }`}>
                      {step.id}
                    </div>
                    {index < steps.length - 1 && (
                      <div className={`flex-1 h-1 mx-2 ${
                        currentStep > step.id ? "bg-primary" : "bg-muted"
                      }`}></div>
                    )}
                  </div>
                  <div className={`mt-2 text-sm font-medium ${
                    currentStep >= step.id ? "text-foreground" : "text-muted-foreground"
                  }`}>
                    {step.title}
                  </div>
                </div>
              ))}
            </div>
            
            {/* Order Form */}
            <div className="crypto-card rounded-xl p-8">
              {/* Step 1: Select Asset */}
              {currentStep === 1 && (
                <div className="space-y-6" data-testid="step-select-asset">
                  <h3 className="text-xl font-semibold mb-4">Select Trading Pair</h3>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="from-asset">You Pay</Label>
                      <Select value={fromAsset} onValueChange={setFromAsset}>
                        <SelectTrigger data-testid="select-from-asset">
                          <SelectValue placeholder="Select asset" />
                        </SelectTrigger>
                        <SelectContent>
                          {cryptoAssets?.map((asset) => (
                            <SelectItem key={asset.id} value={asset.id}>
                              {asset.symbol} ({asset.network})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="to-asset">You Receive</Label>
                      <Select value={toAsset} onValueChange={setToAsset}>
                        <SelectTrigger data-testid="select-to-asset">
                          <SelectValue placeholder="Select asset" />
                        </SelectTrigger>
                        <SelectContent>
                          {cryptoAssets?.filter(asset => asset.id !== fromAsset).map((asset) => (
                            <SelectItem key={asset.id} value={asset.id}>
                              {asset.symbol} ({asset.network})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  {fromAssetData && toAssetData && (
                    <div className="bg-muted/50 rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Exchange Rate</span>
                        <span className="font-mono font-medium" data-testid="text-exchange-rate">
                          1 {fromAssetData.symbol} = {mockExchangeRate} {toAssetData.symbol}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Step 2: Enter Amount */}
              {currentStep === 2 && (
                <div className="space-y-6" data-testid="step-enter-amount">
                  <h3 className="text-xl font-semibold mb-4">Enter Amount</h3>
                  
                  <div>
                    <Label htmlFor="amount">Amount ({fromAssetData?.symbol})</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={fromAmount}
                      onChange={(e) => setFromAmount(e.target.value)}
                      placeholder="0.00"
                      className="text-lg"
                      data-testid="input-amount"
                    />
                  </div>

                  {fromAmount && (
                    <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">You'll receive</span>
                        <span className="font-mono font-semibold" data-testid="text-receive-amount">
                          {calculatedToAmount} {toAssetData?.symbol}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Network fee</span>
                        <span className="font-mono">{networkFee} {fromAssetData?.symbol}</span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Step 3: Review Order */}
              {currentStep === 3 && (
                <div className="space-y-6" data-testid="step-review-order">
                  <h3 className="text-xl font-semibold mb-4">Review Order</h3>
                  
                  <div className="bg-muted/50 rounded-lg p-6 space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Trading Pair</span>
                      <span className="font-semibold">
                        {fromAssetData?.symbol} → {toAssetData?.symbol}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">You Pay</span>
                      <span className="font-mono font-semibold">
                        {fromAmount} {fromAssetData?.symbol}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">You Receive</span>
                      <span className="font-mono font-semibold">
                        {calculatedToAmount} {toAssetData?.symbol}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Network Fee</span>
                      <span className="font-mono">{networkFee} {fromAssetData?.symbol}</span>
                    </div>
                    <div className="border-t border-border pt-4 flex justify-between items-center font-semibold">
                      <span>Total</span>
                      <span className="font-mono">
                        {(parseFloat(fromAmount) + parseFloat(networkFee)).toFixed(2)} {fromAssetData?.symbol}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between mt-8">
                {currentStep > 1 && (
                  <Button
                    variant="outline"
                    onClick={() => setCurrentStep(currentStep - 1)}
                    data-testid="button-back"
                  >
                    Back
                  </Button>
                )}
                <div className="ml-auto">
                  {currentStep < 3 ? (
                    <Button onClick={handleNext} data-testid="button-continue">
                      Continue
                    </Button>
                  ) : (
                    <Button
                      onClick={handleConfirmOrder}
                      disabled={createOrderMutation.isPending}
                      className="glow-effect"
                      data-testid="button-confirm-order"
                    >
                      {createOrderMutation.isPending ? "Processing..." : "Confirm Order"}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <OrderConfirmationModal
        isOpen={isConfirmationOpen}
        onClose={() => setIsConfirmationOpen(false)}
        order={createdOrder}
      />
    </>
  );
}
