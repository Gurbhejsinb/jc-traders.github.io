import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
}

const products: Product[] = [
  {
    id: 1,
    name: "4 T-Shirts Pack",
    description: "High-quality cotton T-shirts (Pack of 4)",
    price: 7.99,
    imageUrl: "/images/tshirt1.png",
  },
  {
    id: 2,
    name: "Casual T-Shirt",
    description: "Comfortable and stylish casual wear",
    price: 3.50,
    imageUrl: "/images/tshirt2.png",
  },
  {
    id: 3,
    name: "Sports T-Shirt",
    description: "Lightweight and breathable fabric",
    price: 4.25,
    imageUrl: "/images/tshirt3.png",
  },
];

export default function ProductGallery() {
  return (
    <section className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="crypto-card border-border card-hover overflow-hidden">
              <CardHeader>
                <CardTitle>{product.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="w-full h-48 object-cover mb-4"
                />
                <p>{product.description}</p>
                <p className="text-2xl font-bold">${product.price}</p>
              </CardContent>
              <CardFooter>
                <Button>Buy Now</Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
