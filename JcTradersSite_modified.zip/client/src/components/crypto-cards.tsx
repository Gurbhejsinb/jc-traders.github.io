import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ArrowUpIcon, ArrowDownIcon } from "lucide-react";
import type { CryptoAsset } from "@shared/schema";

interface CryptoCardsProps {
  onSelectCrypto: (asset: CryptoAsset) => void;
}

// Mock price data - in production this would come from a real API
const mockPrices = {
  USDT: { price: "1.00", change: "+0.12%" },
  BNB: { price: "312.50", change: "+2.45%" },
  TRX: { price: "0.085", change: "-1.23%" },
  BTC: { price: "43,250.00", change: "+3.45%" },
  ETH: { price: "2,650.00", change: "+1.23%" },
};

const assetLogos = {
  USDT: "https://cryptologos.cc/logos/tether-usdt-logo.png",
  BNB: "https://cryptologos.cc/logos/bnb-bnb-logo.png",
  TRX: "https://cryptologos.cc/logos/tron-trx-logo.png",
  BTC: "https://cryptologos.cc/logos/bitcoin-btc-logo.png",
  ETH: "https://cryptologos.cc/logos/ethereum-eth-logo.png",
};

export default function CryptoCards({ onSelectCrypto }: CryptoCardsProps) {
  const { data: cryptoAssets, isLoading } = useQuery<CryptoAsset[]>({
    queryKey: ["/api/crypto-assets"],
  });

  if (isLoading) {
    return (
      <section id="markets" className="py-16 bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Supported Cryptocurrencies</h2>
            <p className="text-muted-foreground">Trade with your preferred crypto payment method</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="crypto-card rounded-xl p-6 animate-pulse">
                <div className="h-20 bg-muted rounded mb-4"></div>
                <div className="h-4 bg-muted rounded mb-2"></div>
                <div className="h-4 bg-muted rounded mb-4"></div>
                <div className="h-10 bg-muted rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  const displayAssets = cryptoAssets?.slice(0, 3) || [];

  return (
    <section id="markets" className="py-16 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Supported Cryptocurrencies</h2>
          <p className="text-muted-foreground">Trade with your preferred crypto payment method</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {displayAssets.map((asset) => {
            const priceData = mockPrices[asset.symbol as keyof typeof mockPrices];
            const isPositive = priceData?.change.startsWith("+");
            
            return (
              <div key={asset.id} className="crypto-card rounded-xl p-6 card-hover" data-testid={`card-crypto-${asset.symbol}`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <img 
                      src={assetLogos[asset.symbol as keyof typeof assetLogos]} 
                      alt={asset.symbol}
                      className="w-12 h-12 rounded-full"
                      data-testid={`img-${asset.symbol}-logo`}
                    />
                    <div>
                      <h3 className="font-semibold text-lg" data-testid={`text-${asset.symbol}-name`}>{asset.symbol}</h3>
                      <p className="text-sm text-muted-foreground" data-testid={`text-${asset.symbol}-network`}>{asset.network}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {priceData && (
                      <>
                        <div className={`text-sm flex items-center ${isPositive ? "text-success" : "text-destructive"}`}>
                          {isPositive ? <ArrowUpIcon className="w-3 h-3 mr-1" /> : <ArrowDownIcon className="w-3 h-3 mr-1" />}
                          {priceData.change}
                        </div>
                        <div className="font-mono text-lg" data-testid={`text-${asset.symbol}-price`}>${priceData.price}</div>
                      </>
                    )}
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Network</span>
                    <span className="font-medium">{asset.network}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Fee</span>
                    <span className="font-medium">0.1%</span>
                  </div>
                </div>
                <Button
                  onClick={() => onSelectCrypto(asset)}
                  className="w-full mt-4 bg-primary/20 text-primary hover:bg-primary/30"
                  variant="outline"
                  data-testid={`button-trade-${asset.symbol}`}
                >
                  Trade {asset.symbol}
                </Button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
