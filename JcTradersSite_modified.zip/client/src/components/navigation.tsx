import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWallet } from "@/hooks/use-wallet";
import WalletModal from "./wallet-modal";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [location] = useLocation();
  const { isConnected, walletAddress, disconnect } = useWallet();

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const toggleWalletModal = () => setIsWalletModalOpen(!isWalletModalOpen);

  const isActive = (path: string) => location === path;

  const formatWalletAddress = (address: string) => {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  return (
    <>
      <nav className="sticky top-0 z-50 border-b border-border backdrop-blur bg-background/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" data-testid="link-home">
              <div className="flex items-center space-x-2 cursor-pointer">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                  <span className="text-xl font-bold">JC</span>
                </div>
                <span className="text-xl font-bold">JC Traders</span>
              </div>
            </Link>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" data-testid="link-markets">
                <span className={`transition-colors cursor-pointer ${
                  isActive("/") ? "text-primary" : "text-muted-foreground hover:text-foreground"
                }`}>
                  Markets
                </span>
              </Link>
              <Link href="/trade" data-testid="link-trade">
                <span className={`transition-colors cursor-pointer ${
                  isActive("/trade") ? "text-primary" : "text-muted-foreground hover:text-foreground"
                }`}>
                  Trade
                </span>
              </Link>
              <Link href="/portfolio" data-testid="link-portfolio">
                <span className={`transition-colors cursor-pointer ${
                  isActive("/portfolio") ? "text-primary" : "text-muted-foreground hover:text-foreground"
                }`}>
                  Portfolio
                </span>
              </Link>
              <Link href="/dashboard" data-testid="link-dashboard">
                <span className={`transition-colors cursor-pointer ${
                  isActive("/dashboard") ? "text-primary" : "text-muted-foreground hover:text-foreground"
                }`}>
                  Dashboard
                </span>
              </Link>
            </div>
            
            {/* Wallet Connect Button */}
            <div className="hidden md:block">
              {isConnected ? (
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground" data-testid="text-wallet-address">
                    {formatWalletAddress(walletAddress!)}
                  </span>
                  <Button
                    onClick={disconnect}
                    variant="outline"
                    size="sm"
                    data-testid="button-disconnect-wallet"
                  >
                    Disconnect
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={toggleWalletModal}
                  className="glow-effect"
                  data-testid="button-connect-wallet"
                >
                  Connect Wallet
                </Button>
              )}
            </div>
            
            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMobileMenu}
              className="md:hidden"
              data-testid="button-mobile-menu"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-card border-t border-border">
            <div className="p-4 space-y-4">
              <Link href="/">
                <span className="block py-2 text-muted-foreground hover:text-foreground transition-colors">
                  Markets
                </span>
              </Link>
              <Link href="/trade">
                <span className="block py-2 text-muted-foreground hover:text-foreground transition-colors">
                  Trade
                </span>
              </Link>
              <Link href="/portfolio">
                <span className="block py-2 text-muted-foreground hover:text-foreground transition-colors">
                  Portfolio
                </span>
              </Link>
              <Link href="/dashboard">
                <span className="block py-2 text-muted-foreground hover:text-foreground transition-colors">
                  Dashboard
                </span>
              </Link>
              {isConnected ? (
                <div className="space-y-2">
                  <span className="text-sm text-muted-foreground">
                    {formatWalletAddress(walletAddress!)}
                  </span>
                  <Button onClick={disconnect} variant="outline" size="sm" className="w-full">
                    Disconnect Wallet
                  </Button>
                </div>
              ) : (
                <Button onClick={toggleWalletModal} className="w-full">
                  Connect Wallet
                </Button>
              )}
            </div>
          </div>
        )}
      </nav>

      <WalletModal isOpen={isWalletModalOpen} onClose={() => setIsWalletModalOpen(false)} />
    </>
  );
}
