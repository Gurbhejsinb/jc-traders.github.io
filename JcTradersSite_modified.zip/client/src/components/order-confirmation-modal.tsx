import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, ExternalLink } from "lucide-react";
import type { Order } from "@shared/schema";

interface OrderConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
}

export default function OrderConfirmationModal({ isOpen, onClose, order }: OrderConfirmationModalProps) {
  if (!order) return null;

  const handleViewTransaction = () => {
    // In a real app, this would navigate to a transaction details page
    // or open the transaction in a blockchain explorer
    console.log("View transaction:", order.transactionHash);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg" data-testid="confirmation-modal">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-success" />
          </div>
          <h3 className="text-2xl font-bold mb-2" data-testid="modal-success-title">Order Confirmed!</h3>
          <p className="text-muted-foreground">Your transaction has been successfully processed</p>
        </div>
        
        {/* Order Details */}
        <div className="bg-muted/50 rounded-lg p-4 space-y-3 mb-6">
          <div className="flex justify-between" data-testid="order-detail-id">
            <span className="text-muted-foreground">Order ID</span>
            <span className="font-mono font-medium">{order.id.substring(0, 12)}...</span>
          </div>
          <div className="flex justify-between" data-testid="order-detail-amount">
            <span className="text-muted-foreground">Amount</span>
            <span className="font-mono font-medium">{order.toAmount}</span>
          </div>
          <div className="flex justify-between" data-testid="order-detail-paid">
            <span className="text-muted-foreground">Paid with</span>
            <span className="font-mono font-medium">{order.fromAmount}</span>
          </div>
          <div className="flex justify-between" data-testid="order-detail-fee">
            <span className="text-muted-foreground">Network Fee</span>
            <span className="font-mono font-medium">{order.networkFee || "0"}</span>
          </div>
          <div className="border-t border-border pt-3 flex justify-between font-semibold">
            <span>Status</span>
            <Badge className="bg-primary/20 text-primary">
              {order.status}
            </Badge>
          </div>
        </div>
        
        {/* Transaction Hash */}
        {order.transactionHash && (
          <div className="bg-primary/10 border border-primary/30 rounded-lg p-4 mb-6">
            <div className="text-xs text-muted-foreground mb-1">Transaction Hash</div>
            <div className="font-mono text-sm break-all text-primary" data-testid="transaction-hash">
              {order.transactionHash}
            </div>
          </div>
        )}
        
        <div className="flex gap-3">
          <Button onClick={onClose} variant="outline" className="flex-1" data-testid="button-close">
            Close
          </Button>
          <Button onClick={handleViewTransaction} className="flex-1" data-testid="button-view-details">
            <ExternalLink className="w-4 h-4 mr-2" />
            View Details
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
