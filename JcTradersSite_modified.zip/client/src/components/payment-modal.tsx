import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Copy, Check } from "lucide-react";
import type { Product } from "@shared/schema";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
  selectedSize: string;
  onPaymentComplete: (paymentMethod: string) => void;
}

const paymentMethods = [
  {
    name: "USDT (BEP20)",
    network: "BEP20",
    address: "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb",
    icon: "https://cryptologos.cc/logos/tether-usdt-logo.png",
  },
  {
    name: "TRON (TRX)",
    network: "TRON",
    address: "TRX7NqpLdYlQ5nM8V3K3yG4ZqJ8F9YnPeR",
    icon: "https://cryptologos.cc/logos/tron-trx-logo.png",
  },
  {
    name: "BNB",
    network: "BSC",
    address: "0x892d42Bb6634C0532925a3b844Bc9e7595f1AfC",
    icon: "https://cryptologos.cc/logos/bnb-bnb-logo.png",
  },
];

export default function PaymentModal({ isOpen, onClose, product, selectedSize, onPaymentComplete }: PaymentModalProps) {
  const [selectedPayment, setSelectedPayment] = useState<string | null>(null);
  const [copiedAddress, setCopiedAddress] = useState<string | null>(null);

  if (!product) return null;

  const selectedMethod = paymentMethods.find(m => m.name === selectedPayment);

  const handleCopyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    setCopiedAddress(address);
    setTimeout(() => setCopiedAddress(null), 2000);
  };

  const handleContinue = () => {
    if (selectedPayment) {
      onPaymentComplete(selectedPayment);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md" data-testid="payment-modal">
        <DialogHeader>
          <DialogTitle>Select Payment Method</DialogTitle>
          <DialogDescription>
            Choose your preferred cryptocurrency to complete the purchase
          </DialogDescription>
        </DialogHeader>

        <div className="mb-4 p-4 bg-muted/50 rounded-lg">
          <div className="text-sm text-muted-foreground">Order Summary</div>
          <div className="font-semibold">{product.name}</div>
          <div className="text-sm text-muted-foreground">Size: {selectedSize}</div>
          <div className="text-lg font-bold gradient-text mt-2">${product.price}</div>
        </div>

        {!selectedPayment ? (
          <div className="space-y-3">
            {paymentMethods.map((method) => (
              <Card
                key={method.name}
                className="p-4 cursor-pointer hover:border-primary transition-colors"
                onClick={() => setSelectedPayment(method.name)}
                data-testid={`payment-option-${method.network}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <img src={method.icon} alt={method.name} className="w-10 h-10 rounded-full" />
                    <div>
                      <div className="font-semibold">{method.name}</div>
                      <div className="text-sm text-muted-foreground">{method.network}</div>
                    </div>
                  </div>
                  <div className="text-primary">→</div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            <Card className="p-4 bg-primary/10 border-primary/30">
              <div className="flex items-center space-x-3 mb-3">
                <img src={selectedMethod!.icon} alt={selectedMethod!.name} className="w-10 h-10 rounded-full" />
                <div>
                  <div className="font-semibold">{selectedMethod!.name}</div>
                  <div className="text-sm text-muted-foreground">{selectedMethod!.network}</div>
                </div>
              </div>
              
              <div className="text-sm text-muted-foreground mb-1">Send ${product.price} to:</div>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-xs bg-background p-2 rounded border break-all">
                  {selectedMethod!.address}
                </code>
                <Button
                  size="icon"
                  variant="outline"
                  onClick={() => handleCopyAddress(selectedMethod!.address)}
                  data-testid="button-copy-address"
                >
                  {copiedAddress === selectedMethod!.address ? (
                    <Check className="w-4 h-4 text-success" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </Card>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setSelectedPayment(null)}
                className="flex-1"
                data-testid="button-back-payment"
              >
                Back
              </Button>
              <Button
                onClick={handleContinue}
                className="flex-1 glow-effect"
                data-testid="button-continue-payment"
              >
                I've Sent Payment
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
