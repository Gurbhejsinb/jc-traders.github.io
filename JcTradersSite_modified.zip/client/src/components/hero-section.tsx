import { Button } from "@/components/ui/button";
import { useWallet } from "@/hooks/use-wallet";

interface HeroSectionProps {
  onStartTrading: () => void;
}

export default function HeroSection({ onStartTrading }: HeroSectionProps) {
  const { isConnected } = useWallet();

  return (
    <section className="relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary rounded-full blur-3xl"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-32">
        <div className="text-center">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold mb-6">
            Trade Crypto with
            <span className="gradient-text block mt-2">Confidence & Security</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Professional crypto trading platform supporting USDT BEP20, BNB, and TRON. Start trading with seamless wallet integration and instant transactions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={onStartTrading}
              size="lg"
              className="glow-effect text-lg px-8 py-4"
              data-testid="button-start-trading"
            >
              Start Trading
            </Button>
            {!isConnected && (
              <Button
                variant="secondary"
                size="lg"
                className="text-lg px-8 py-4"
                data-testid="button-connect-wallet-hero"
              >
                Connect Wallet
              </Button>
            )}
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 mt-16 max-w-3xl mx-auto">
            <div>
              <div className="text-3xl font-bold gradient-text" data-testid="stat-trading-volume">$2.5B+</div>
              <div className="text-sm text-muted-foreground mt-1">Trading Volume</div>
            </div>
            <div>
              <div className="text-3xl font-bold gradient-text" data-testid="stat-active-traders">150K+</div>
              <div className="text-sm text-muted-foreground mt-1">Active Traders</div>
            </div>
            <div>
              <div className="text-3xl font-bold gradient-text" data-testid="stat-trading-pairs">50+</div>
              <div className="text-sm text-muted-foreground mt-1">Trading Pairs</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
