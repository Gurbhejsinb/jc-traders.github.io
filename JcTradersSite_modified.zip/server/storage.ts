import { 
  type Product, type InsertProduct,
  type Order, type InsertOrder
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order>;
}

export class MemStorage implements IStorage {
  private products: Map<string, Product> = new Map();
  private orders: Map<string, Order> = new Map();

  constructor() {
    this.initializeDefaultProducts();
  }

  private initializeDefaultProducts() {
    const tshirtProducts = [
      {
        name: "JC Traders Classic Logo Tee",
        description: "Premium cotton T-shirt with JC Traders gradient logo",
        price: "29.99",
        imageUrl: "/attached_assets/tshirt2_1759504192298.png",
        sizes: ["S", "M", "L", "XL", "XXL"],
      },
      {
        name: "JC Traders Text Edition",
        description: "Bold text design T-shirt with gradient colors",
        price: "29.99",
        imageUrl: "/attached_assets/generated_images/JC_Traders_text_t-shirt_e11bc92b.png",
        sizes: ["S", "M", "L", "XL", "XXL"],
      },
      {
        name: "Crypto Symbol Collection",
        description: "Geometric crypto symbol with modern gradient",
        price: "32.99",
        imageUrl: "/attached_assets/generated_images/Crypto_symbol_t-shirt_c4595468.png",
        sizes: ["S", "M", "L", "XL", "XXL"],
      },
      {
        name: "Abstract Wave Design",
        description: "Artistic wave pattern with JC monogram",
        price: "32.99",
        imageUrl: "/attached_assets/generated_images/Abstract_wave_pattern_t-shirt_8604be73.png",
        sizes: ["S", "M", "L", "XL", "XXL"],
      },
    ];

    tshirtProducts.forEach(product => {
      const id = randomUUID();
      const newProduct: Product = { ...product, id, createdAt: new Date() };
      this.products.set(id, newProduct);
    });
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { 
      ...insertProduct, 
      id,
      createdAt: new Date()
    };
    this.products.set(id, product);
    return product;
  }

  // Orders
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = { 
      ...insertOrder, 
      id,
      status: insertOrder.status ?? "pending",
      createdAt: new Date()
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order> {
    const order = this.orders.get(id);
    if (!order) {
      throw new Error("Order not found");
    }
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
}

export const storage = new MemStorage();
